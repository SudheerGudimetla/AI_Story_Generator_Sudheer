# AI Story Generator by Sudheer

This app generates creative stories based on user prompts using GPT-2.
Built with Streamlit and Hugging Face Transformers.

## How to Run

1. Install requirements: `pip install -r requirements.txt`
2. Run app: `streamlit run app.py`